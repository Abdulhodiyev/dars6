-- 1. books nomli jadval yarating, unda quyidagi ustunlar boâ€˜lsin:
--     kitob nomi, muallif ismi, chop etilgan yili, va narxi.


CREATE TABLE books(
    book_name VARCHAR(100) NOT NULL,
    author VARCHAR(100) NOT NULL,
    year_of_publication date NOT NULL,
    price INTEGER NOT NULL
);


